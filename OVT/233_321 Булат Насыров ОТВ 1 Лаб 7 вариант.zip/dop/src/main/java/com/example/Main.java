package com.example;

public class Main {
    public static void main(String[] args) {
        int x=4;
        int y=0;
        if(x<21) {
            y = 11 * 12 * 13;
        }
        else {
            y=45;
        }
        
        System.out.println(y);
    }
}