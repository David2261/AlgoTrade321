package com.example.domain;

public interface Pet {
    String getName();
    void setName (String name);
    void play ();
}
